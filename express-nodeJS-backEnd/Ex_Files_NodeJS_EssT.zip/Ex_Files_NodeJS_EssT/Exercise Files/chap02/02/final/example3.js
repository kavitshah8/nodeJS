var say = require('./proclaim');

say.softly('we have extra seats available.');

say.loudly('ALL FLIGHTS CANCELLED.');
