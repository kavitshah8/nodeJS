var os = require('os');

console.log('This code is running on: ' + os.type());
