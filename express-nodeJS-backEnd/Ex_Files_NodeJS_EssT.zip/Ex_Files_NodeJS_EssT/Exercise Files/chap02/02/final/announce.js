module.exports = function (announcement) {
	console.log('Announcing: ' + announcement);
};